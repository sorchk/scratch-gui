(window["webpackJsonpGUI"] = window["webpackJsonpGUI"] || []).push([["tr-steps"],{

/***/ "./src/lib/libraries/decks/steps/add-effects.tr.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-effects.tr.png ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/94db901f0d56f241af20a247363bce9a.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/add-variable.tr.gif":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-variable.tr.gif ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/5535f63d90bcb911bb5eb1844a80981d.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-add-sound.tr.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-add-sound.tr.png ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/2ba3e406ddf90348369b580a59b8de26.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-change-color.tr.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-change-color.tr.png ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a5adf1ebee60e8a998929bcfa0b14844.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-jump.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-jump.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a09773def64c710875b46b3c0ca8549c.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-move.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-move.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/fca6d0b4b6450d3305260e82b392155c.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-say-something.tr.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-say-something.tr.png ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/5c7aef090784f2c93ec2efee0c9bd6c8.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-talk.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-talk.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/caf16273a566477c7d6fbe7a5eedc5c0.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/change-size.tr.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/change-size.tr.png ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/0ad4f7b010b7c161ccdbdf5ea640c12d.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-change-score.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-change-score.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/68b50c25d8554b2b642ea26b42060819.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-move-randomly.tr.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-move-randomly.tr.png ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/e48dbd5a1782029a8fa2360fb4ba1f19.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-play-sound.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-play-sound.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/eca255cc2e52faca282430f346dedfd4.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-right-left.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-right-left.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/96f65e8877b4dabe8e8fa69271b94eb2.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-up-down.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-up-down.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/441f818d605df6415b51269d4fd1ed21.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-backdrop.tr.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-backdrop.tr.png ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/98917eee6d87e2c62779c1b780430c6b.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-collect.tr.png":
/*!*********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-collect.tr.png ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a3d5e913469ff07c3576fac9f312b717.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-glide.tr.png":
/*!*******************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-glide.tr.png ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a674fbfdd19c1692a5e3b667d7f70e67.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-say.tr.png":
/*!*****************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-say.tr.png ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/eaf4325fac98b4a3a160dcd17e2909ca.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-score.tr.png":
/*!*******************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-score.tr.png ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/5e8d35e10b13c9fa9f140983dc0700ca.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.tr.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-01-say-something.tr.png ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/979520fc7f2f44c9189e94e387b80e01.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-02-animate.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/74e61812d4f7c5620b86eac4b7d214fd.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.tr.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.tr.png ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/e301dbda6b370b31505f75ec0a8d6fee.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.tr.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.tr.png ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/10da6cc8ff4b0625464b7833ceb6f1b0.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-07-jump.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8475994a5fcdec354f439b9042163bc3.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.tr.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.tr.png ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/230c50c72908a602d92faf1af36bb026.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.tr.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.tr.png ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/1439974d80867862c54cfb48be043dfa.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.tr.png":
/*!******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.tr.png ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/fd3601b8ca4839c693797c5ec19a42fe.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-flying-heart.tr.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-flying-heart.tr.png ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/e31df8e64a7d6216199c1c70a2b9a074.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-keep-score.tr.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-keep-score.tr.png ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/97b5549849b4f975f137423b5642f217.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-make-interactive.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-make-interactive.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/fa1ca804731813f7b6336f022c9f7a15.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-move-scenery.tr.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-move-scenery.tr.png ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/03be0afb8c044559ff59268d9b300da4.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-say-something.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-say-something.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/b6e8cd443224857d9e6fa31f6b4ddd12.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-switch-costume.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-switch-costume.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/82c8c7584b9a525c7f42c204eab6e44f.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.tr.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-back-and-forth.tr.png ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/fd290d53be8c706ee1e9367f30b00453.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-point.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-point.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/1dd550093bcd6a17fe0faeb598c4614a.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/hide-show.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/hide-show.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ce56b695ae8ccb5faa8c80276b408999.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-change-costumes.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-change-costumes.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/973c43bb12ccb7bd424c19e86aa9f203.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-choose-sound.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-choose-sound.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/2a24a4521494dfaf2c60d5cd81dee336.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-click-green-flag.tr.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-click-green-flag.tr.png ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/213583db3aa18af39c5304e34ad2e081.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-fly-around.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-fly-around.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/dee2410c13e2843784ae6f063366129a.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-glide-to-point.tr.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-glide-to-point.tr.png ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/02ba444be8e58971337ad57d4ea46049.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-grow-shrink.tr.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-grow-shrink.tr.png ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ba1df64f73538e3ea9499ada68705881.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-left-right.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-left-right.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/c293e6a0c6f526b23c67be14c4b9c798.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-record-a-sound.tr.gif":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-record-a-sound.tr.gif ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a180b5a515554072a228fa3078541968.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.tr.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-switch-backdrops.tr.png ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/61abbe6b69e28b9a05d995be380b7148.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.tr.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-type-what-you-want.tr.png ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8a72332ddef41a941a461eed2173f314.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-up-down.tr.png":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-up-down.tr.png ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/14c23970cf59b177856ba2ad63cdb35e.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-1-move.tr.gif":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-1-move.tr.gif ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/e2745bdb19ddd7c58173894ab902195c.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-2-say.tr.gif":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-2-say.tr.gif ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/87f64db6eb759b554c26f5b6b8957bb8.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-3-green-flag.tr.gif":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-3-green-flag.tr.gif ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/7e1705b0b84cc2bbb37fa5d8f8ebd60e.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.tr.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-left-right.tr.png ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/04b45c8c2b3e98654c966e721df7bc02.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-up-down.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/24a5e493dba23aa417244f7bc3ae2925.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beat.tr.png":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beat.tr.png ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9cc88045f3cabd4c3fcd624d9ace1cde.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beatbox.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beatbox.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/a4db5bb0139609010db34971359adab1.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-song.tr.png":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-song.tr.png ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/3f2380f56cad46f2062cef8d912653e3.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-play-sound.tr.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-play-sound.tr.png ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ffe953993b2e78e5475c9a2031963630.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-change-color.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-change-color.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/7187ea45b8c390dd9792ad0eaf5a53c7.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-grow.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-grow.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/becd595db949fd660134892de5242462.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-play-sound.tr.png":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-play-sound.tr.png ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/fa5af041d82443d56f92c01ee4aa7b0b.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-spin.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-spin.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/444917d4a77ee0a819149fe1830d4ce9.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-add-code-to-ball.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/be6855aafcd708ca1144407be3525eba.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-bounce-around.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-bounce-around.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/df9f89ac9ca6f20ed0515b2f1f8a14f4.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-choose-score.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-choose-score.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/7f285395d3b6f228543346bc9bd9a7e8.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-game-over.tr.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-game-over.tr.png ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/08fb8965604ff7f53cbb084ca7abafcf.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-insert-change-score.tr.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-insert-change-score.tr.png ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/1935b436ac96e68f0790cd9e63d934f8.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-move-the-paddle.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-move-the-paddle.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/06fff8fafea226704401002c48ef1e06.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-reset-score.tr.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-reset-score.tr.png ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/3331f77a86b0a0fcf1a88100272e17ad.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-color.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-color.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/be64f545fb6f2ee960066076ca1d2cad.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-score.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-score.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/de249f29522f229c1fd18fd30e6d5894.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-play-sound.tr.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-play-sound.tr.png ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/c6e2f2a5f46ef6ce88efdc82ef40e807.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-random-position.tr.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-random-position.tr.png ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/3a12322df7e0962a2c2c6e349f7a94c9.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-reset-score.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-reset-score.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/16176109364ad32d0e86d797c4e8693b.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.tr.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-choose-sound.tr.png ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9fe52c3fce039f46a14829bab3a8de27.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-click-record.tr.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-click-record.tr.png ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/b40b5b135b5815108bdd0f1a3d704ed8.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.tr.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.tr.png ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8aa1f01ddaf394148ece8a931fcd342f.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.tr.png":
/*!*********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-press-record-button.tr.png ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8566f52d6609ec465a7a4aa8a5b4351b.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.tr.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.tr.png ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/f11c7c6e9d2a9213f8fcd254a62c5423.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-add-extension.tr.gif":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-add-extension.tr.gif ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ce07991d8c3de08cf53ce1969069aa66.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-change-color.tr.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-change-color.tr.png ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/d4059f479110da75caa243a8fb6dcfa3.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-grow-shrink.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-grow-shrink.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/250e1b5178b3225fd6ba31f0c8887d2f.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-move-around.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-move-around.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/7474db8a69cfc0dc5582b4fa86122ff9.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-say-something.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-say-something.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/59c5591d77baf06776e324910362118d.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-set-voice.tr.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-set-voice.tr.png ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/98eb24b8d132596b468c2a31a3c7a797.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-song.tr.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-song.tr.png ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ebadd75f0186b97ad76e4ab8d085b27b.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-spin.tr.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-spin.tr.png ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/f92ee1c77808d911e3054bf943cc204c.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-point-in-direction.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-point-in-direction.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/bd05eb10105eeb31a1163dd67455f68a.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-turn.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-turn.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8f450d3f5813d38fa4522638f27808b2.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-conversation.tr.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-conversation.tr.png ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/02996fe6baaf299100f573314f88a9cb.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-flip.tr.gif":
/*!*********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-flip.tr.gif ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9af4b3064503d658a55fbf2008a24959.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-hide-character.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-hide-character.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/5f2678812e5dd475fc752571066d2fe8.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-say-something.tr.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-say-something.tr.png ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9e8d31f21665138485fd0f35336941d3.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-show-character.tr.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-show-character.tr.png ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/bc34eb5b1d16d40406a5c7e7092a2696.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-switch-backdrop.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-switch-backdrop.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/efdcf973b0345d1cb68ec99539cf70e0.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/switch-costumes.tr.png":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/switch-costumes.tr.png ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9e66a3e58cf070433edfc415d28bbdf9.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-11-choose-sound.tr.gif":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-11-choose-sound.tr.gif ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/9bc0fa7cab5684056158d09d085d49e3.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-12-dance-moves.tr.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-12-dance-moves.tr.png ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/af5a438a2b88e40eaa0216c256bb847a.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.tr.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-13-ask-and-answer.tr.png ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/ee2fde6dce11006d5c9dd7d55bd6d04e.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-3-say-something.tr.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-3-say-something.tr.png ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/f1b1f5bba8a4adba5eaba47ff4f4ed9f.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.tr.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-5-switch-backdrop.tr.png ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/e1fc659560ff4a605f7db920be7a2463.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-7-move-around.tr.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-7-move-around.tr.png ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/6aa60807dc9db68551c1a86387eaa66f.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-9-animate.tr.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-9-animate.tr.png ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/af02888e81748cc742c63f5e21e1739c.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-add-extension.tr.gif":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-add-extension.tr.gif ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/471bbaab8238e35be181e1d958f1181c.gif");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-animate.tr.png":
/*!************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-animate.tr.png ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/6e5e6bcb4cb11921f93c491bc9d2c25d.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pet.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pet.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/5c6e45385e798895444ce4002d4ec101.png");

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pop.tr.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pop.tr.png ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/assets/8934ddd913df4498ad8745642ed19e13.png");

/***/ }),

/***/ "./src/lib/libraries/decks/tr-steps.js":
/*!*********************************************!*\
  !*** ./src/lib/libraries/decks/tr-steps.js ***!
  \*********************************************/
/*! exports provided: trImages */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trImages", function() { return trImages; });
/* harmony import */ var _steps_intro_1_move_tr_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./steps/intro-1-move.tr.gif */ "./src/lib/libraries/decks/steps/intro-1-move.tr.gif");
/* harmony import */ var _steps_intro_2_say_tr_gif__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./steps/intro-2-say.tr.gif */ "./src/lib/libraries/decks/steps/intro-2-say.tr.gif");
/* harmony import */ var _steps_intro_3_green_flag_tr_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./steps/intro-3-green-flag.tr.gif */ "./src/lib/libraries/decks/steps/intro-3-green-flag.tr.gif");
/* harmony import */ var _steps_speech_add_extension_tr_gif__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./steps/speech-add-extension.tr.gif */ "./src/lib/libraries/decks/steps/speech-add-extension.tr.gif");
/* harmony import */ var _steps_speech_say_something_tr_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./steps/speech-say-something.tr.png */ "./src/lib/libraries/decks/steps/speech-say-something.tr.png");
/* harmony import */ var _steps_speech_set_voice_tr_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./steps/speech-set-voice.tr.png */ "./src/lib/libraries/decks/steps/speech-set-voice.tr.png");
/* harmony import */ var _steps_speech_move_around_tr_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./steps/speech-move-around.tr.png */ "./src/lib/libraries/decks/steps/speech-move-around.tr.png");
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./steps/pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/pick-backdrop.LTR.gif");
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./steps/speech-add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/speech-add-sprite.LTR.gif");
/* harmony import */ var _steps_speech_song_tr_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./steps/speech-song.tr.png */ "./src/lib/libraries/decks/steps/speech-song.tr.png");
/* harmony import */ var _steps_speech_change_color_tr_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./steps/speech-change-color.tr.png */ "./src/lib/libraries/decks/steps/speech-change-color.tr.png");
/* harmony import */ var _steps_speech_spin_tr_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./steps/speech-spin.tr.png */ "./src/lib/libraries/decks/steps/speech-spin.tr.png");
/* harmony import */ var _steps_speech_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./steps/speech-grow-shrink.tr.png */ "./src/lib/libraries/decks/steps/speech-grow-shrink.tr.png");
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./steps/cn-show-character.LTR.gif */ "./src/lib/libraries/decks/steps/cn-show-character.LTR.gif");
/* harmony import */ var _steps_cn_say_tr_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./steps/cn-say.tr.png */ "./src/lib/libraries/decks/steps/cn-say.tr.png");
/* harmony import */ var _steps_cn_glide_tr_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./steps/cn-glide.tr.png */ "./src/lib/libraries/decks/steps/cn-glide.tr.png");
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./steps/cn-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/cn-pick-sprite.LTR.gif");
/* harmony import */ var _steps_cn_collect_tr_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./steps/cn-collect.tr.png */ "./src/lib/libraries/decks/steps/cn-collect.tr.png");
/* harmony import */ var _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./steps/add-variable.tr.gif */ "./src/lib/libraries/decks/steps/add-variable.tr.gif");
/* harmony import */ var _steps_cn_score_tr_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./steps/cn-score.tr.png */ "./src/lib/libraries/decks/steps/cn-score.tr.png");
/* harmony import */ var _steps_cn_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./steps/cn-backdrop.tr.png */ "./src/lib/libraries/decks/steps/cn-backdrop.tr.png");
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./steps/add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/add-sprite.LTR.gif");
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./steps/name-pick-letter.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter.LTR.gif");
/* harmony import */ var _steps_name_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./steps/name-play-sound.tr.png */ "./src/lib/libraries/decks/steps/name-play-sound.tr.png");
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./steps/name-pick-letter2.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter2.LTR.gif");
/* harmony import */ var _steps_name_change_color_tr_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./steps/name-change-color.tr.png */ "./src/lib/libraries/decks/steps/name-change-color.tr.png");
/* harmony import */ var _steps_name_spin_tr_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./steps/name-spin.tr.png */ "./src/lib/libraries/decks/steps/name-spin.tr.png");
/* harmony import */ var _steps_name_grow_tr_png__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./steps/name-grow.tr.png */ "./src/lib/libraries/decks/steps/name-grow.tr.png");
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./steps/music-pick-instrument.LTR.gif */ "./src/lib/libraries/decks/steps/music-pick-instrument.LTR.gif");
/* harmony import */ var _steps_music_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./steps/music-play-sound.tr.png */ "./src/lib/libraries/decks/steps/music-play-sound.tr.png");
/* harmony import */ var _steps_music_make_song_tr_png__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./steps/music-make-song.tr.png */ "./src/lib/libraries/decks/steps/music-make-song.tr.png");
/* harmony import */ var _steps_music_make_beat_tr_png__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./steps/music-make-beat.tr.png */ "./src/lib/libraries/decks/steps/music-make-beat.tr.png");
/* harmony import */ var _steps_music_make_beatbox_tr_png__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./steps/music-make-beatbox.tr.png */ "./src/lib/libraries/decks/steps/music-make-beatbox.tr.png");
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./steps/chase-game-add-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-backdrop.LTR.gif");
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./steps/chase-game-add-sprite1.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite1.LTR.gif");
/* harmony import */ var _steps_chase_game_right_left_tr_png__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./steps/chase-game-right-left.tr.png */ "./src/lib/libraries/decks/steps/chase-game-right-left.tr.png");
/* harmony import */ var _steps_chase_game_up_down_tr_png__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./steps/chase-game-up-down.tr.png */ "./src/lib/libraries/decks/steps/chase-game-up-down.tr.png");
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./steps/chase-game-add-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite2.LTR.gif");
/* harmony import */ var _steps_chase_game_move_randomly_tr_png__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./steps/chase-game-move-randomly.tr.png */ "./src/lib/libraries/decks/steps/chase-game-move-randomly.tr.png");
/* harmony import */ var _steps_chase_game_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./steps/chase-game-play-sound.tr.png */ "./src/lib/libraries/decks/steps/chase-game-play-sound.tr.png");
/* harmony import */ var _steps_chase_game_change_score_tr_png__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./steps/chase-game-change-score.tr.png */ "./src/lib/libraries/decks/steps/chase-game-change-score.tr.png");
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./steps/pop-game-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/pop-game-pick-sprite.LTR.gif");
/* harmony import */ var _steps_pop_game_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./steps/pop-game-play-sound.tr.png */ "./src/lib/libraries/decks/steps/pop-game-play-sound.tr.png");
/* harmony import */ var _steps_pop_game_change_score_tr_png__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./steps/pop-game-change-score.tr.png */ "./src/lib/libraries/decks/steps/pop-game-change-score.tr.png");
/* harmony import */ var _steps_pop_game_random_position_tr_png__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./steps/pop-game-random-position.tr.png */ "./src/lib/libraries/decks/steps/pop-game-random-position.tr.png");
/* harmony import */ var _steps_pop_game_change_color_tr_png__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./steps/pop-game-change-color.tr.png */ "./src/lib/libraries/decks/steps/pop-game-change-color.tr.png");
/* harmony import */ var _steps_pop_game_reset_score_tr_png__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./steps/pop-game-reset-score.tr.png */ "./src/lib/libraries/decks/steps/pop-game-reset-score.tr.png");
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./steps/animate-char-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/animate-char-pick-sprite.LTR.gif");
/* harmony import */ var _steps_animate_char_say_something_tr_png__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./steps/animate-char-say-something.tr.png */ "./src/lib/libraries/decks/steps/animate-char-say-something.tr.png");
/* harmony import */ var _steps_animate_char_add_sound_tr_png__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./steps/animate-char-add-sound.tr.png */ "./src/lib/libraries/decks/steps/animate-char-add-sound.tr.png");
/* harmony import */ var _steps_animate_char_talk_tr_png__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./steps/animate-char-talk.tr.png */ "./src/lib/libraries/decks/steps/animate-char-talk.tr.png");
/* harmony import */ var _steps_animate_char_move_tr_png__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./steps/animate-char-move.tr.png */ "./src/lib/libraries/decks/steps/animate-char-move.tr.png");
/* harmony import */ var _steps_animate_char_jump_tr_png__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./steps/animate-char-jump.tr.png */ "./src/lib/libraries/decks/steps/animate-char-jump.tr.png");
/* harmony import */ var _steps_animate_char_change_color_tr_png__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./steps/animate-char-change-color.tr.png */ "./src/lib/libraries/decks/steps/animate-char-change-color.tr.png");
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./steps/story-pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop.LTR.gif");
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./steps/story-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite.LTR.gif");
/* harmony import */ var _steps_story_say_something_tr_png__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./steps/story-say-something.tr.png */ "./src/lib/libraries/decks/steps/story-say-something.tr.png");
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./steps/story-pick-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite2.LTR.gif");
/* harmony import */ var _steps_story_flip_tr_gif__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./steps/story-flip.tr.gif */ "./src/lib/libraries/decks/steps/story-flip.tr.gif");
/* harmony import */ var _steps_story_conversation_tr_png__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./steps/story-conversation.tr.png */ "./src/lib/libraries/decks/steps/story-conversation.tr.png");
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ./steps/story-pick-backdrop2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop2.LTR.gif");
/* harmony import */ var _steps_story_switch_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ./steps/story-switch-backdrop.tr.png */ "./src/lib/libraries/decks/steps/story-switch-backdrop.tr.png");
/* harmony import */ var _steps_story_hide_character_tr_png__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ./steps/story-hide-character.tr.png */ "./src/lib/libraries/decks/steps/story-hide-character.tr.png");
/* harmony import */ var _steps_story_show_character_tr_png__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ./steps/story-show-character.tr.png */ "./src/lib/libraries/decks/steps/story-show-character.tr.png");
/* harmony import */ var _steps_video_add_extension_tr_gif__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! ./steps/video-add-extension.tr.gif */ "./src/lib/libraries/decks/steps/video-add-extension.tr.gif");
/* harmony import */ var _steps_video_pet_tr_png__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! ./steps/video-pet.tr.png */ "./src/lib/libraries/decks/steps/video-pet.tr.png");
/* harmony import */ var _steps_video_animate_tr_png__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! ./steps/video-animate.tr.png */ "./src/lib/libraries/decks/steps/video-animate.tr.png");
/* harmony import */ var _steps_video_pop_tr_png__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! ./steps/video-pop.tr.png */ "./src/lib/libraries/decks/steps/video-pop.tr.png");
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(/*! ./steps/fly-choose-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-backdrop.LTR.gif");
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(/*! ./steps/fly-choose-character.LTR.png */ "./src/lib/libraries/decks/steps/fly-choose-character.LTR.png");
/* harmony import */ var _steps_fly_say_something_tr_png__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(/*! ./steps/fly-say-something.tr.png */ "./src/lib/libraries/decks/steps/fly-say-something.tr.png");
/* harmony import */ var _steps_fly_make_interactive_tr_png__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(/*! ./steps/fly-make-interactive.tr.png */ "./src/lib/libraries/decks/steps/fly-make-interactive.tr.png");
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(/*! ./steps/fly-object-to-collect.LTR.png */ "./src/lib/libraries/decks/steps/fly-object-to-collect.LTR.png");
/* harmony import */ var _steps_fly_flying_heart_tr_png__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(/*! ./steps/fly-flying-heart.tr.png */ "./src/lib/libraries/decks/steps/fly-flying-heart.tr.png");
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(/*! ./steps/fly-select-flyer.LTR.png */ "./src/lib/libraries/decks/steps/fly-select-flyer.LTR.png");
/* harmony import */ var _steps_fly_keep_score_tr_png__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(/*! ./steps/fly-keep-score.tr.png */ "./src/lib/libraries/decks/steps/fly-keep-score.tr.png");
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(/*! ./steps/fly-choose-scenery.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-scenery.LTR.gif");
/* harmony import */ var _steps_fly_move_scenery_tr_png__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(/*! ./steps/fly-move-scenery.tr.png */ "./src/lib/libraries/decks/steps/fly-move-scenery.tr.png");
/* harmony import */ var _steps_fly_switch_costume_tr_png__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(/*! ./steps/fly-switch-costume.tr.png */ "./src/lib/libraries/decks/steps/fly-switch-costume.tr.png");
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(/*! ./steps/pong-add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-backdrop.LTR.png");
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(/*! ./steps/pong-add-ball-sprite.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-ball-sprite.LTR.png");
/* harmony import */ var _steps_pong_bounce_around_tr_png__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(/*! ./steps/pong-bounce-around.tr.png */ "./src/lib/libraries/decks/steps/pong-bounce-around.tr.png");
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(/*! ./steps/pong-add-a-paddle.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-a-paddle.LTR.gif");
/* harmony import */ var _steps_pong_move_the_paddle_tr_png__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(/*! ./steps/pong-move-the-paddle.tr.png */ "./src/lib/libraries/decks/steps/pong-move-the-paddle.tr.png");
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(/*! ./steps/pong-select-ball.LTR.png */ "./src/lib/libraries/decks/steps/pong-select-ball.LTR.png");
/* harmony import */ var _steps_pong_add_code_to_ball_tr_png__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(/*! ./steps/pong-add-code-to-ball.tr.png */ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.tr.png");
/* harmony import */ var _steps_pong_choose_score_tr_png__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(/*! ./steps/pong-choose-score.tr.png */ "./src/lib/libraries/decks/steps/pong-choose-score.tr.png");
/* harmony import */ var _steps_pong_insert_change_score_tr_png__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(/*! ./steps/pong-insert-change-score.tr.png */ "./src/lib/libraries/decks/steps/pong-insert-change-score.tr.png");
/* harmony import */ var _steps_pong_reset_score_tr_png__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(/*! ./steps/pong-reset-score.tr.png */ "./src/lib/libraries/decks/steps/pong-reset-score.tr.png");
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(/*! ./steps/pong-add-line.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-line.LTR.gif");
/* harmony import */ var _steps_pong_game_over_tr_png__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(/*! ./steps/pong-game-over.tr.png */ "./src/lib/libraries/decks/steps/pong-game-over.tr.png");
/* harmony import */ var _steps_imagine_type_what_you_want_tr_png__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(/*! ./steps/imagine-type-what-you-want.tr.png */ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.tr.png");
/* harmony import */ var _steps_imagine_click_green_flag_tr_png__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(/*! ./steps/imagine-click-green-flag.tr.png */ "./src/lib/libraries/decks/steps/imagine-click-green-flag.tr.png");
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(/*! ./steps/imagine-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(/*! ./steps/imagine-choose-any-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-any-sprite.LTR.png");
/* harmony import */ var _steps_imagine_fly_around_tr_png__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(/*! ./steps/imagine-fly-around.tr.png */ "./src/lib/libraries/decks/steps/imagine-fly-around.tr.png");
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(/*! ./steps/imagine-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_imagine_left_right_tr_png__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(/*! ./steps/imagine-left-right.tr.png */ "./src/lib/libraries/decks/steps/imagine-left-right.tr.png");
/* harmony import */ var _steps_imagine_up_down_tr_png__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(/*! ./steps/imagine-up-down.tr.png */ "./src/lib/libraries/decks/steps/imagine-up-down.tr.png");
/* harmony import */ var _steps_imagine_change_costumes_tr_png__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(/*! ./steps/imagine-change-costumes.tr.png */ "./src/lib/libraries/decks/steps/imagine-change-costumes.tr.png");
/* harmony import */ var _steps_imagine_glide_to_point_tr_png__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(/*! ./steps/imagine-glide-to-point.tr.png */ "./src/lib/libraries/decks/steps/imagine-glide-to-point.tr.png");
/* harmony import */ var _steps_imagine_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(/*! ./steps/imagine-grow-shrink.tr.png */ "./src/lib/libraries/decks/steps/imagine-grow-shrink.tr.png");
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(/*! ./steps/imagine-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_switch_backdrops_tr_png__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(/*! ./steps/imagine-switch-backdrops.tr.png */ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.tr.png");
/* harmony import */ var _steps_imagine_record_a_sound_tr_gif__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(/*! ./steps/imagine-record-a-sound.tr.gif */ "./src/lib/libraries/decks/steps/imagine-record-a-sound.tr.gif");
/* harmony import */ var _steps_imagine_choose_sound_tr_png__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(/*! ./steps/imagine-choose-sound.tr.png */ "./src/lib/libraries/decks/steps/imagine-choose-sound.tr.png");
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(/*! ./steps/add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/add-backdrop.LTR.png");
/* harmony import */ var _steps_add_effects_tr_png__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(/*! ./steps/add-effects.tr.png */ "./src/lib/libraries/decks/steps/add-effects.tr.png");
/* harmony import */ var _steps_hide_show_tr_png__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(/*! ./steps/hide-show.tr.png */ "./src/lib/libraries/decks/steps/hide-show.tr.png");
/* harmony import */ var _steps_switch_costumes_tr_png__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(/*! ./steps/switch-costumes.tr.png */ "./src/lib/libraries/decks/steps/switch-costumes.tr.png");
/* harmony import */ var _steps_change_size_tr_png__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(/*! ./steps/change-size.tr.png */ "./src/lib/libraries/decks/steps/change-size.tr.png");
/* harmony import */ var _steps_spin_turn_tr_png__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(/*! ./steps/spin-turn.tr.png */ "./src/lib/libraries/decks/steps/spin-turn.tr.png");
/* harmony import */ var _steps_spin_point_in_direction_tr_png__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(/*! ./steps/spin-point-in-direction.tr.png */ "./src/lib/libraries/decks/steps/spin-point-in-direction.tr.png");
/* harmony import */ var _steps_record_a_sound_sounds_tab_tr_png__WEBPACK_IMPORTED_MODULE_113__ = __webpack_require__(/*! ./steps/record-a-sound-sounds-tab.tr.png */ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.tr.png");
/* harmony import */ var _steps_record_a_sound_click_record_tr_png__WEBPACK_IMPORTED_MODULE_114__ = __webpack_require__(/*! ./steps/record-a-sound-click-record.tr.png */ "./src/lib/libraries/decks/steps/record-a-sound-click-record.tr.png");
/* harmony import */ var _steps_record_a_sound_press_record_button_tr_png__WEBPACK_IMPORTED_MODULE_115__ = __webpack_require__(/*! ./steps/record-a-sound-press-record-button.tr.png */ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.tr.png");
/* harmony import */ var _steps_record_a_sound_choose_sound_tr_png__WEBPACK_IMPORTED_MODULE_116__ = __webpack_require__(/*! ./steps/record-a-sound-choose-sound.tr.png */ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.tr.png");
/* harmony import */ var _steps_record_a_sound_play_your_sound_tr_png__WEBPACK_IMPORTED_MODULE_117__ = __webpack_require__(/*! ./steps/record-a-sound-play-your-sound.tr.png */ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.tr.png");
/* harmony import */ var _steps_move_arrow_keys_left_right_tr_png__WEBPACK_IMPORTED_MODULE_118__ = __webpack_require__(/*! ./steps/move-arrow-keys-left-right.tr.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.tr.png");
/* harmony import */ var _steps_move_arrow_keys_up_down_tr_png__WEBPACK_IMPORTED_MODULE_119__ = __webpack_require__(/*! ./steps/move-arrow-keys-up-down.tr.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.tr.png");
/* harmony import */ var _steps_glide_around_back_and_forth_tr_png__WEBPACK_IMPORTED_MODULE_120__ = __webpack_require__(/*! ./steps/glide-around-back-and-forth.tr.png */ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.tr.png");
/* harmony import */ var _steps_glide_around_point_tr_png__WEBPACK_IMPORTED_MODULE_121__ = __webpack_require__(/*! ./steps/glide-around-point.tr.png */ "./src/lib/libraries/decks/steps/glide-around-point.tr.png");
/* harmony import */ var _steps_code_cartoon_01_say_something_tr_png__WEBPACK_IMPORTED_MODULE_122__ = __webpack_require__(/*! ./steps/code-cartoon-01-say-something.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.tr.png");
/* harmony import */ var _steps_code_cartoon_02_animate_tr_png__WEBPACK_IMPORTED_MODULE_123__ = __webpack_require__(/*! ./steps/code-cartoon-02-animate.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.tr.png");
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__ = __webpack_require__(/*! ./steps/code-cartoon-03-select-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-03-select-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_tr_png__WEBPACK_IMPORTED_MODULE_125__ = __webpack_require__(/*! ./steps/code-cartoon-04-use-minus-sign.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.tr.png");
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_126__ = __webpack_require__(/*! ./steps/code-cartoon-05-grow-shrink.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.tr.png");
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__ = __webpack_require__(/*! ./steps/code-cartoon-06-select-another-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-06-select-another-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_07_jump_tr_png__WEBPACK_IMPORTED_MODULE_128__ = __webpack_require__(/*! ./steps/code-cartoon-07-jump.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.tr.png");
/* harmony import */ var _steps_code_cartoon_08_change_scenes_tr_png__WEBPACK_IMPORTED_MODULE_129__ = __webpack_require__(/*! ./steps/code-cartoon-08-change-scenes.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.tr.png");
/* harmony import */ var _steps_code_cartoon_09_glide_around_tr_png__WEBPACK_IMPORTED_MODULE_130__ = __webpack_require__(/*! ./steps/code-cartoon-09-glide-around.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.tr.png");
/* harmony import */ var _steps_code_cartoon_10_change_costumes_tr_png__WEBPACK_IMPORTED_MODULE_131__ = __webpack_require__(/*! ./steps/code-cartoon-10-change-costumes.tr.png */ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.tr.png");
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__ = __webpack_require__(/*! ./steps/code-cartoon-11-choose-more-characters.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-11-choose-more-characters.LTR.png");
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__ = __webpack_require__(/*! ./steps/talking-2-choose-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-2-choose-sprite.LTR.png");
/* harmony import */ var _steps_talking_3_say_something_tr_png__WEBPACK_IMPORTED_MODULE_134__ = __webpack_require__(/*! ./steps/talking-3-say-something.tr.png */ "./src/lib/libraries/decks/steps/talking-3-say-something.tr.png");
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__ = __webpack_require__(/*! ./steps/talking-4-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-4-choose-backdrop.LTR.png");
/* harmony import */ var _steps_talking_5_switch_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_136__ = __webpack_require__(/*! ./steps/talking-5-switch-backdrop.tr.png */ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.tr.png");
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__ = __webpack_require__(/*! ./steps/talking-6-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-6-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_talking_7_move_around_tr_png__WEBPACK_IMPORTED_MODULE_138__ = __webpack_require__(/*! ./steps/talking-7-move-around.tr.png */ "./src/lib/libraries/decks/steps/talking-7-move-around.tr.png");
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__ = __webpack_require__(/*! ./steps/talking-8-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-8-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_talking_9_animate_tr_png__WEBPACK_IMPORTED_MODULE_140__ = __webpack_require__(/*! ./steps/talking-9-animate.tr.png */ "./src/lib/libraries/decks/steps/talking-9-animate.tr.png");
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__ = __webpack_require__(/*! ./steps/talking-10-choose-third-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-10-choose-third-backdrop.LTR.png");
/* harmony import */ var _steps_talking_11_choose_sound_tr_gif__WEBPACK_IMPORTED_MODULE_142__ = __webpack_require__(/*! ./steps/talking-11-choose-sound.tr.gif */ "./src/lib/libraries/decks/steps/talking-11-choose-sound.tr.gif");
/* harmony import */ var _steps_talking_12_dance_moves_tr_png__WEBPACK_IMPORTED_MODULE_143__ = __webpack_require__(/*! ./steps/talking-12-dance-moves.tr.png */ "./src/lib/libraries/decks/steps/talking-12-dance-moves.tr.png");
/* harmony import */ var _steps_talking_13_ask_and_answer_tr_png__WEBPACK_IMPORTED_MODULE_144__ = __webpack_require__(/*! ./steps/talking-13-ask-and-answer.tr.png */ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.tr.png");
// Intro




// Text to Speech











// Cartoon Network









// Add sprite


// Animate a name







// Make Music






// Chase-Game










// Clicker-Game (Pop Game)








// Animate A Character









// Tell A Story











// Video Sensing





// Make it Fly













// Pong














// Imagine a World
















// Add a Backdrop


// Add Effects


// Hide and Show


// Switch Costumes


// Change Size


// Spin



// Record a Sound






// Use Arrow Keys



// Glide Around



// Code a Cartoon












// Talking Tales













var trImages = {
  // Intro
  introMove: _steps_intro_1_move_tr_gif__WEBPACK_IMPORTED_MODULE_0__["default"],
  introSay: _steps_intro_2_say_tr_gif__WEBPACK_IMPORTED_MODULE_1__["default"],
  introGreenFlag: _steps_intro_3_green_flag_tr_gif__WEBPACK_IMPORTED_MODULE_2__["default"],
  // Text to Speech
  speechAddExtension: _steps_speech_add_extension_tr_gif__WEBPACK_IMPORTED_MODULE_3__["default"],
  speechSaySomething: _steps_speech_say_something_tr_png__WEBPACK_IMPORTED_MODULE_4__["default"],
  speechSetVoice: _steps_speech_set_voice_tr_png__WEBPACK_IMPORTED_MODULE_5__["default"],
  speechMoveAround: _steps_speech_move_around_tr_png__WEBPACK_IMPORTED_MODULE_6__["default"],
  speechAddBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__["default"],
  speechAddSprite: _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__["default"],
  speechSong: _steps_speech_song_tr_png__WEBPACK_IMPORTED_MODULE_9__["default"],
  speechChangeColor: _steps_speech_change_color_tr_png__WEBPACK_IMPORTED_MODULE_10__["default"],
  speechSpin: _steps_speech_spin_tr_png__WEBPACK_IMPORTED_MODULE_11__["default"],
  speechGrowShrink: _steps_speech_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_12__["default"],
  // Cartoon Network
  cnShowCharacter: _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__["default"],
  cnSay: _steps_cn_say_tr_png__WEBPACK_IMPORTED_MODULE_14__["default"],
  cnGlide: _steps_cn_glide_tr_png__WEBPACK_IMPORTED_MODULE_15__["default"],
  cnPickSprite: _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__["default"],
  cnCollect: _steps_cn_collect_tr_png__WEBPACK_IMPORTED_MODULE_17__["default"],
  cnVariable: _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__["default"],
  cnScore: _steps_cn_score_tr_png__WEBPACK_IMPORTED_MODULE_19__["default"],
  cnBackdrop: _steps_cn_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_20__["default"],
  // Add sprite
  addSprite: _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__["default"],
  // Animate a name
  namePickLetter: _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__["default"],
  namePlaySound: _steps_name_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_23__["default"],
  namePickLetter2: _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__["default"],
  nameChangeColor: _steps_name_change_color_tr_png__WEBPACK_IMPORTED_MODULE_25__["default"],
  nameSpin: _steps_name_spin_tr_png__WEBPACK_IMPORTED_MODULE_26__["default"],
  nameGrow: _steps_name_grow_tr_png__WEBPACK_IMPORTED_MODULE_27__["default"],
  // Make-Music
  musicPickInstrument: _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__["default"],
  musicPlaySound: _steps_music_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_29__["default"],
  musicMakeSong: _steps_music_make_song_tr_png__WEBPACK_IMPORTED_MODULE_30__["default"],
  musicMakeBeat: _steps_music_make_beat_tr_png__WEBPACK_IMPORTED_MODULE_31__["default"],
  musicMakeBeatbox: _steps_music_make_beatbox_tr_png__WEBPACK_IMPORTED_MODULE_32__["default"],
  // Chase-Game
  chaseGameAddBackdrop: _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__["default"],
  chaseGameAddSprite1: _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__["default"],
  chaseGameRightLeft: _steps_chase_game_right_left_tr_png__WEBPACK_IMPORTED_MODULE_35__["default"],
  chaseGameUpDown: _steps_chase_game_up_down_tr_png__WEBPACK_IMPORTED_MODULE_36__["default"],
  chaseGameAddSprite2: _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__["default"],
  chaseGameMoveRandomly: _steps_chase_game_move_randomly_tr_png__WEBPACK_IMPORTED_MODULE_38__["default"],
  chaseGamePlaySound: _steps_chase_game_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_39__["default"],
  chaseGameAddVariable: _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__["default"],
  chaseGameChangeScore: _steps_chase_game_change_score_tr_png__WEBPACK_IMPORTED_MODULE_40__["default"],
  // Make-A-Pop/Clicker Game
  popGamePickSprite: _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__["default"],
  popGamePlaySound: _steps_pop_game_play_sound_tr_png__WEBPACK_IMPORTED_MODULE_42__["default"],
  popGameAddScore: _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__["default"],
  popGameChangeScore: _steps_pop_game_change_score_tr_png__WEBPACK_IMPORTED_MODULE_43__["default"],
  popGameRandomPosition: _steps_pop_game_random_position_tr_png__WEBPACK_IMPORTED_MODULE_44__["default"],
  popGameChangeColor: _steps_pop_game_change_color_tr_png__WEBPACK_IMPORTED_MODULE_45__["default"],
  popGameResetScore: _steps_pop_game_reset_score_tr_png__WEBPACK_IMPORTED_MODULE_46__["default"],
  // Animate A Character
  animateCharPickBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__["default"],
  animateCharPickSprite: _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__["default"],
  animateCharSaySomething: _steps_animate_char_say_something_tr_png__WEBPACK_IMPORTED_MODULE_48__["default"],
  animateCharAddSound: _steps_animate_char_add_sound_tr_png__WEBPACK_IMPORTED_MODULE_49__["default"],
  animateCharTalk: _steps_animate_char_talk_tr_png__WEBPACK_IMPORTED_MODULE_50__["default"],
  animateCharMove: _steps_animate_char_move_tr_png__WEBPACK_IMPORTED_MODULE_51__["default"],
  animateCharJump: _steps_animate_char_jump_tr_png__WEBPACK_IMPORTED_MODULE_52__["default"],
  animateCharChangeColor: _steps_animate_char_change_color_tr_png__WEBPACK_IMPORTED_MODULE_53__["default"],
  // Tell A Story
  storyPickBackdrop: _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__["default"],
  storyPickSprite: _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__["default"],
  storySaySomething: _steps_story_say_something_tr_png__WEBPACK_IMPORTED_MODULE_56__["default"],
  storyPickSprite2: _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__["default"],
  storyFlip: _steps_story_flip_tr_gif__WEBPACK_IMPORTED_MODULE_58__["default"],
  storyConversation: _steps_story_conversation_tr_png__WEBPACK_IMPORTED_MODULE_59__["default"],
  storyPickBackdrop2: _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__["default"],
  storySwitchBackdrop: _steps_story_switch_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_61__["default"],
  storyHideCharacter: _steps_story_hide_character_tr_png__WEBPACK_IMPORTED_MODULE_62__["default"],
  storyShowCharacter: _steps_story_show_character_tr_png__WEBPACK_IMPORTED_MODULE_63__["default"],
  // Video Sensing
  videoAddExtension: _steps_video_add_extension_tr_gif__WEBPACK_IMPORTED_MODULE_64__["default"],
  videoPet: _steps_video_pet_tr_png__WEBPACK_IMPORTED_MODULE_65__["default"],
  videoAnimate: _steps_video_animate_tr_png__WEBPACK_IMPORTED_MODULE_66__["default"],
  videoPop: _steps_video_pop_tr_png__WEBPACK_IMPORTED_MODULE_67__["default"],
  // Make it Fly
  flyChooseBackdrop: _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__["default"],
  flyChooseCharacter: _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__["default"],
  flySaySomething: _steps_fly_say_something_tr_png__WEBPACK_IMPORTED_MODULE_70__["default"],
  flyMoveArrows: _steps_fly_make_interactive_tr_png__WEBPACK_IMPORTED_MODULE_71__["default"],
  flyChooseObject: _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__["default"],
  flyFlyingObject: _steps_fly_flying_heart_tr_png__WEBPACK_IMPORTED_MODULE_73__["default"],
  flySelectFlyingSprite: _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__["default"],
  flyAddScore: _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__["default"],
  flyKeepScore: _steps_fly_keep_score_tr_png__WEBPACK_IMPORTED_MODULE_75__["default"],
  flyAddScenery: _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__["default"],
  flyMoveScenery: _steps_fly_move_scenery_tr_png__WEBPACK_IMPORTED_MODULE_77__["default"],
  flySwitchLooks: _steps_fly_switch_costume_tr_png__WEBPACK_IMPORTED_MODULE_78__["default"],
  // Pong
  pongAddBackdrop: _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__["default"],
  pongAddBallSprite: _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__["default"],
  pongBounceAround: _steps_pong_bounce_around_tr_png__WEBPACK_IMPORTED_MODULE_81__["default"],
  pongAddPaddle: _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__["default"],
  pongMoveThePaddle: _steps_pong_move_the_paddle_tr_png__WEBPACK_IMPORTED_MODULE_83__["default"],
  pongSelectBallSprite: _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__["default"],
  pongAddMoreCodeToBall: _steps_pong_add_code_to_ball_tr_png__WEBPACK_IMPORTED_MODULE_85__["default"],
  pongAddAScore: _steps_add_variable_tr_gif__WEBPACK_IMPORTED_MODULE_18__["default"],
  pongChooseScoreFromMenu: _steps_pong_choose_score_tr_png__WEBPACK_IMPORTED_MODULE_86__["default"],
  pongInsertChangeScoreBlock: _steps_pong_insert_change_score_tr_png__WEBPACK_IMPORTED_MODULE_87__["default"],
  pongResetScore: _steps_pong_reset_score_tr_png__WEBPACK_IMPORTED_MODULE_88__["default"],
  pongAddLineSprite: _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__["default"],
  pongGameOver: _steps_pong_game_over_tr_png__WEBPACK_IMPORTED_MODULE_90__["default"],
  // Imagine a World
  imagineTypeWhatYouWant: _steps_imagine_type_what_you_want_tr_png__WEBPACK_IMPORTED_MODULE_91__["default"],
  imagineClickGreenFlag: _steps_imagine_click_green_flag_tr_png__WEBPACK_IMPORTED_MODULE_92__["default"],
  imagineChooseBackdrop: _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__["default"],
  imagineChooseSprite: _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__["default"],
  imagineFlyAround: _steps_imagine_fly_around_tr_png__WEBPACK_IMPORTED_MODULE_95__["default"],
  imagineChooseAnotherSprite: _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__["default"],
  imagineLeftRight: _steps_imagine_left_right_tr_png__WEBPACK_IMPORTED_MODULE_97__["default"],
  imagineUpDown: _steps_imagine_up_down_tr_png__WEBPACK_IMPORTED_MODULE_98__["default"],
  imagineChangeCostumes: _steps_imagine_change_costumes_tr_png__WEBPACK_IMPORTED_MODULE_99__["default"],
  imagineGlideToPoint: _steps_imagine_glide_to_point_tr_png__WEBPACK_IMPORTED_MODULE_100__["default"],
  imagineGrowShrink: _steps_imagine_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_101__["default"],
  imagineChooseAnotherBackdrop: _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__["default"],
  imagineSwitchBackdrops: _steps_imagine_switch_backdrops_tr_png__WEBPACK_IMPORTED_MODULE_103__["default"],
  imagineRecordASound: _steps_imagine_record_a_sound_tr_gif__WEBPACK_IMPORTED_MODULE_104__["default"],
  imagineChooseSound: _steps_imagine_choose_sound_tr_png__WEBPACK_IMPORTED_MODULE_105__["default"],
  // Add a Backdrop
  addBackdrop: _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__["default"],
  // Add Effects
  addEffects: _steps_add_effects_tr_png__WEBPACK_IMPORTED_MODULE_107__["default"],
  // Hide and Show
  hideAndShow: _steps_hide_show_tr_png__WEBPACK_IMPORTED_MODULE_108__["default"],
  // Switch Costumes
  switchCostumes: _steps_switch_costumes_tr_png__WEBPACK_IMPORTED_MODULE_109__["default"],
  // Change Size
  changeSize: _steps_change_size_tr_png__WEBPACK_IMPORTED_MODULE_110__["default"],
  // Spin
  spinTurn: _steps_spin_turn_tr_png__WEBPACK_IMPORTED_MODULE_111__["default"],
  spinPointInDirection: _steps_spin_point_in_direction_tr_png__WEBPACK_IMPORTED_MODULE_112__["default"],
  // Record a Sound
  recordASoundSoundsTab: _steps_record_a_sound_sounds_tab_tr_png__WEBPACK_IMPORTED_MODULE_113__["default"],
  recordASoundClickRecord: _steps_record_a_sound_click_record_tr_png__WEBPACK_IMPORTED_MODULE_114__["default"],
  recordASoundPressRecordButton: _steps_record_a_sound_press_record_button_tr_png__WEBPACK_IMPORTED_MODULE_115__["default"],
  recordASoundChooseSound: _steps_record_a_sound_choose_sound_tr_png__WEBPACK_IMPORTED_MODULE_116__["default"],
  recordASoundPlayYourSound: _steps_record_a_sound_play_your_sound_tr_png__WEBPACK_IMPORTED_MODULE_117__["default"],
  // Use Arrow Keys
  moveArrowKeysLeftRight: _steps_move_arrow_keys_left_right_tr_png__WEBPACK_IMPORTED_MODULE_118__["default"],
  moveArrowKeysUpDown: _steps_move_arrow_keys_up_down_tr_png__WEBPACK_IMPORTED_MODULE_119__["default"],
  // Glide Around
  glideAroundBackAndForth: _steps_glide_around_back_and_forth_tr_png__WEBPACK_IMPORTED_MODULE_120__["default"],
  glideAroundPoint: _steps_glide_around_point_tr_png__WEBPACK_IMPORTED_MODULE_121__["default"],
  // Code a Cartoon
  codeCartoonSaySomething: _steps_code_cartoon_01_say_something_tr_png__WEBPACK_IMPORTED_MODULE_122__["default"],
  codeCartoonAnimate: _steps_code_cartoon_02_animate_tr_png__WEBPACK_IMPORTED_MODULE_123__["default"],
  codeCartoonSelectDifferentCharacter: _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__["default"],
  codeCartoonUseMinusSign: _steps_code_cartoon_04_use_minus_sign_tr_png__WEBPACK_IMPORTED_MODULE_125__["default"],
  codeCartoonGrowShrink: _steps_code_cartoon_05_grow_shrink_tr_png__WEBPACK_IMPORTED_MODULE_126__["default"],
  codeCartoonSelectDifferentCharacter2: _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__["default"],
  codeCartoonJump: _steps_code_cartoon_07_jump_tr_png__WEBPACK_IMPORTED_MODULE_128__["default"],
  codeCartoonChangeScenes: _steps_code_cartoon_08_change_scenes_tr_png__WEBPACK_IMPORTED_MODULE_129__["default"],
  codeCartoonGlideAround: _steps_code_cartoon_09_glide_around_tr_png__WEBPACK_IMPORTED_MODULE_130__["default"],
  codeCartoonChangeCostumes: _steps_code_cartoon_10_change_costumes_tr_png__WEBPACK_IMPORTED_MODULE_131__["default"],
  codeCartoonChooseMoreCharacters: _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__["default"],
  // Talking Tales
  talesAddExtension: _steps_speech_add_extension_tr_gif__WEBPACK_IMPORTED_MODULE_3__["default"],
  talesChooseSprite: _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__["default"],
  talesSaySomething: _steps_talking_3_say_something_tr_png__WEBPACK_IMPORTED_MODULE_134__["default"],
  talesAskAnswer: _steps_talking_13_ask_and_answer_tr_png__WEBPACK_IMPORTED_MODULE_144__["default"],
  talesChooseBackdrop: _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__["default"],
  talesSwitchBackdrop: _steps_talking_5_switch_backdrop_tr_png__WEBPACK_IMPORTED_MODULE_136__["default"],
  talesChooseAnotherSprite: _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__["default"],
  talesMoveAround: _steps_talking_7_move_around_tr_png__WEBPACK_IMPORTED_MODULE_138__["default"],
  talesChooseAnotherBackdrop: _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__["default"],
  talesAnimateTalking: _steps_talking_9_animate_tr_png__WEBPACK_IMPORTED_MODULE_140__["default"],
  talesChooseThirdBackdrop: _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__["default"],
  talesChooseSound: _steps_talking_11_choose_sound_tr_gif__WEBPACK_IMPORTED_MODULE_142__["default"],
  talesDanceMoves: _steps_talking_12_dance_moves_tr_png__WEBPACK_IMPORTED_MODULE_143__["default"]
};


/***/ })

}]);
//# sourceMappingURL=tr-steps.js.map